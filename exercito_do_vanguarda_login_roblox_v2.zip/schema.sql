CREATE TABLE IF NOT EXISTS ev_pending_verifications (
  user_id TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  code TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ev_sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  username TEXT NOT NULL,
  rank_name TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ev_sessions_expiration ON ev_sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_ev_pending_expiration ON ev_pending_verifications(expires_at);
