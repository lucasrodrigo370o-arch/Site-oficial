const GROUP_ID = '1060387642';
const PREFIX = 'Ebdovanguarda';
const CODE_WORDS = [
  'Cadeira','Mesa','Livro','Caneta','Lapis','Caderno','Relogio','Mochila','Janela','Porta',
  'Chave','Garrafa','Copo','Prato','Colher','Garfo','Panela','Toalha','Travesseiro','Cobertor',
  'Sapato','Camisa','Boné','Carteira','Oculos','Fone','Teclado','Mouse','Monitor','Celular',
  'Carregador','Lampada','Ventilador','Espelho','Quadro','Vaso','Tapete','Sofa','Cama','Armario',
  'Controle','Bola','Bicicleta','Patins','GuardaChuva','Escova','Sabonete','Pente','Tesoura','Regua',
  'Borracha','Apontador','Papel','Pasta','Envelope','Calendario','Agenda','Calculadora','Impressora','Notebook'
];
const json = (data, status=200, headers={}) => new Response(JSON.stringify(data), {status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}});
const fail = (message,status=400)=>json({error:message},status);
const enc = new TextEncoder();
const sha256 = async value => [...new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(value)))].map(x=>x.toString(16).padStart(2,'0')).join('');
const iso = ms => new Date(ms).toISOString();
async function body(req){try{return await req.json()}catch{return null}}
function cookieValue(req,name){const raw=req.headers.get('Cookie')||'';const part=raw.split(';').map(v=>v.trim()).find(v=>v.startsWith(name+'='));return part?decodeURIComponent(part.slice(name.length+1)):null;}
async function currentSession(req,env){
 const token=cookieValue(req,'ev_session');if(!token)return null;
 return env.DB.prepare('SELECT user_id, username, rank_name, expires_at FROM ev_sessions WHERE token_hash=? AND expires_at>?').bind(await sha256(token),iso(Date.now())).first();
}
async function robloxUserByName(username){
 const response=await fetch('https://users.roblox.com/v1/usernames/users',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({usernames:[username],excludeBannedUsers:false})});
 if(!response.ok)throw new Error('O Roblox não conseguiu consultar esse usuário agora. Tente novamente.');
 const result=await response.json();return result.data?.[0]||null;
}
async function profileDescription(userId){
 const response=await fetch(`https://users.roblox.com/v1/users/${encodeURIComponent(userId)}`);
 if(!response.ok)throw new Error('Não foi possível consultar a bio desse perfil. Verifique se o perfil está público e tente novamente.');
 const result=await response.json();return typeof result.description==='string'?result.description:'';
}
async function groupRank(userId){
 const url=`https://groups.roblox.com/v2/users/${encodeURIComponent(userId)}/groups/roles?includeLocked=false&includeNotificationPreferences=false&discoveryType=0`;
 const response=await fetch(url);
 if(!response.ok)throw new Error('A bio foi confirmada, mas o Roblox não retornou os dados do grupo. Tente novamente.');
 const result=await response.json();
 const rows=Array.isArray(result.data)?result.data:[];
 const membership=rows.find(item=>String(item.group?.id)===GROUP_ID);
 if(!membership)return 'Não integrante do grupo';
 return membership.role?.name||'Membro do grupo';
}
function randomIndex(max){const bytes=new Uint32Array(1);crypto.getRandomValues(bytes);return bytes[0]%max;}
function newCode(previous){
 let code='';
 while(true){
  let a=randomIndex(CODE_WORDS.length),b=randomIndex(CODE_WORDS.length);
  while(b===a)b=randomIndex(CODE_WORDS.length);
  code=`${PREFIX}-${CODE_WORDS[a]}-${CODE_WORDS[b]}`;
  if(code!==previous)return code;
 }
}
async function handle(request,env){
 const url=new URL(request.url);const path=url.pathname;
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{'Allow':'GET, POST, OPTIONS'}});
 if(path==='/api/session'&&request.method==='GET'){
  const session=await currentSession(request,env);
  if(!session)return json({authenticated:false});
  let currentRank=session.rank_name;
  try{currentRank=await groupRank(session.user_id);await env.DB.prepare('UPDATE ev_sessions SET rank_name=? WHERE user_id=?').bind(currentRank,session.user_id).run();}catch(e){}
  return json({authenticated:true,user:{userId:session.user_id,username:session.username,rank:currentRank}});
 }
 if(path==='/api/roblox/start'&&request.method==='POST'){
  const data=await body(request);const username=String(data?.username||'').trim();
  if(!/^[A-Za-z0-9_]{3,20}$/.test(username))return fail('Digite um nome de usuário Roblox válido.');
  let user;try{user=await robloxUserByName(username)}catch(e){return fail(e.message,502)}
  if(!user)return fail('Não encontramos esse nome de usuário no Roblox.',404);
  const previous=await env.DB.prepare('SELECT code FROM ev_pending_verifications WHERE user_id=?').bind(String(user.id)).first();
  const code=newCode(previous?.code||'');const expires=iso(Date.now()+10*60*1000);
  await env.DB.prepare('INSERT INTO ev_pending_verifications(user_id,username,code,expires_at,created_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,code=excluded.code,expires_at=excluded.expires_at,created_at=excluded.created_at')
   .bind(String(user.id),user.name,code,expires,iso(Date.now())).run();
  return json({userId:String(user.id),username:user.name,code,expiresAt:expires});
 }
 if(path==='/api/roblox/verify'&&request.method==='POST'){
  const data=await body(request);const userId=String(data?.userId||'');
  if(!/^\d{1,20}$/.test(userId))return fail('Solicitação de verificação inválida.');
  const pending=await env.DB.prepare('SELECT user_id,username,code,expires_at FROM ev_pending_verifications WHERE user_id=? AND expires_at>?').bind(userId,iso(Date.now())).first();
  if(!pending)return fail('O código expirou. Gere um novo código para continuar.',410);
  let description;try{description=await profileDescription(userId)}catch(e){return fail(e.message,502)}
  if(!description.includes(pending.code))return fail('Ainda não encontramos o código na bio. Confira se foi copiado por inteiro e tente novamente.',409);
  let rank;try{rank=await groupRank(userId)}catch(e){return fail(e.message,502)}
  await env.DB.prepare('DELETE FROM ev_pending_verifications WHERE user_id=?').bind(userId).run();
  const token=crypto.randomUUID()+crypto.randomUUID();const expires=iso(Date.now()+365*24*60*60*1000);
  await env.DB.prepare('INSERT INTO ev_sessions(token_hash,user_id,username,rank_name,expires_at,created_at) VALUES(?,?,?,?,?,?)')
   .bind(await sha256(token),userId,pending.username,rank,expires,iso(Date.now())).run();
  const cookie=`ev_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=31536000`;
  return json({verified:true,user:{userId,username:pending.username,rank} },200,{'Set-Cookie':cookie});
 }
 if(path==='/api/logout'&&request.method==='POST'){
  const token=cookieValue(request,'ev_session');if(token)await env.DB.prepare('DELETE FROM ev_sessions WHERE token_hash=?').bind(await sha256(token)).run();
  return json({ok:true},200,{'Set-Cookie':'ev_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'});
 }
 if(env.ASSETS)return env.ASSETS.fetch(request);
 return fail('Rota não encontrada.',404);
}
export default {fetch:handle};
