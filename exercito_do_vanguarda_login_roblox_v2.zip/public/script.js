const loginScreen=document.getElementById('loginScreen');
const appShell=document.getElementById('appShell');
const loginMessage=document.getElementById('loginMessage');
const startForm=document.getElementById('startVerifyForm');
const codeStage=document.getElementById('codeStage');
const usernameInput=document.getElementById('robloxUsername');
const generatedCode=document.getElementById('generatedCode');
const confirmButton=document.getElementById('confirmVerifyButton');
let pendingUser=null;

async function api(path,options={}){
 const response=await fetch(path,{...options,headers:{'Content-Type':'application/json',...(options.headers||{})},credentials:'same-origin'});
 const data=await response.json().catch(()=>({error:'Resposta inválida do servidor.'}));
 if(!response.ok)throw new Error(data.error||'Não foi possível concluir a solicitação.');
 return data;
}
function showLogin(message=''){
 appShell.hidden=true;loginScreen.hidden=false;loginMessage.textContent=message;
}
function showDashboard(user){
 loginScreen.hidden=true;appShell.hidden=false;
 document.getElementById('signedUsername').textContent=user.username||'Usuário Roblox';
 document.getElementById('signedRank').textContent=user.rank||'Membro não encontrado no grupo';
 document.getElementById('topbarAccount').textContent=user.username||'';
}
async function restoreSession(){
 try{const data=await api('/api/session',{method:'GET',headers:{}});if(data.authenticated){showDashboard(data.user);return;}}
 catch(e){}
 showLogin();
}
startForm.addEventListener('submit',async event=>{
 event.preventDefault();
 const username=usernameInput.value.trim();
 if(!username)return;
 const button=document.getElementById('generateCodeButton');button.disabled=true;button.textContent='Gerando...';loginMessage.textContent='';
 try{
  const data=await api('/api/roblox/start',{method:'POST',body:JSON.stringify({username})});
  pendingUser={userId:data.userId,username:data.username};generatedCode.textContent=data.code;
  document.getElementById('robloxProfileLink').href=`https://www.roblox.com/users/${data.userId}/profile`;
  codeStage.hidden=false;loginMessage.textContent='Código gerado. Coloque-o na descrição do perfil Roblox.';
 }catch(error){loginMessage.textContent=error.message;}
 finally{button.disabled=false;button.textContent='Gerar código de verificação';}
});
document.getElementById('copyCodeButton').addEventListener('click',async()=>{
 try{await navigator.clipboard.writeText(generatedCode.textContent);loginMessage.textContent='Código copiado.';}
 catch(e){loginMessage.textContent='Não foi possível copiar automaticamente. Selecione o código e copie.';}
});
confirmButton.addEventListener('click',async()=>{
 if(!pendingUser)return;
 confirmButton.disabled=true;confirmButton.textContent='Verificando...';loginMessage.textContent='Consultando a descrição do perfil Roblox...';
 try{
  const data=await api('/api/roblox/verify',{method:'POST',body:JSON.stringify({userId:pendingUser.userId})});
  showDashboard(data.user);
 }catch(error){loginMessage.textContent=error.message;}
 finally{confirmButton.disabled=false;confirmButton.textContent='Já coloquei na bio — verificar';}
});
document.getElementById('logoutButton').addEventListener('click',async()=>{
 try{await api('/api/logout',{method:'POST',body:'{}'});}catch(e){}
 pendingUser=null;codeStage.hidden=true;startForm.reset();showLogin('Sessão encerrada neste dispositivo.');
});

const sidebar=document.getElementById('sidebar');
const backdrop=document.getElementById('backdrop');
const openMenu=document.getElementById('openMenu');
const closeMenu=document.getElementById('closeMenu');
const searchInput=document.getElementById('searchInput');
function setMenu(open){sidebar.classList.toggle('open',open);backdrop.classList.toggle('show',open);}
openMenu.addEventListener('click',()=>setMenu(true));
closeMenu.addEventListener('click',()=>setMenu(false));
backdrop.addEventListener('click',()=>setMenu(false));
searchInput.addEventListener('input',()=>{
 const query=searchInput.value.trim().toLocaleLowerCase('pt-BR');
 document.querySelectorAll('.menu-item').forEach(item=>{item.style.display=item.dataset.search.includes(query)?'':'none';});
});
restoreSession();
